from setuptools import setup

setup(name='serializer-from-hell',
      version='1.0',
      description='json and xml sers',
      packages=['Lab3', 'Lab3/constants', 'Lab3/funcs', 'Lab3/package'],
      author_email='sea25042003@gmail.com',
      zip_safe=False)